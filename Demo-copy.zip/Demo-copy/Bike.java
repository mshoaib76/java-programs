class Vehicle{

    int speed =50;
    
    Vehicle()
    {
        //this.speed = speed;
        System.out.println("This is Super Class Constructor");
    }
    
    //# Method Overriding
    void display(){
            
                  
        System.out.println("This is Super Class");  
    }
}


public class Bike extends Vehicle {

        int speed = 100;
        
        public Bike()
        {
            //#3.super is used to invoke parent class constructor
            super(); 
        }
        
        void display(){
            System.out.println("This is Sub Class");
           //#2 super is used to refer immediate parent class method
            //     super.display();
            
           //#1 super is used to refer immediate parent class instance variable
           //     System.out.println(super.speed);      
           //     System.out.println(speed);  
        }
        
        public static void main(String[] args)
        {
                Bike b = new Bike();
                
                
                b.display();
        
        }
}

