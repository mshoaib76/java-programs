package ClassA;

class C{
    
    public C(){
            System.out.println("Constructor of C Class");
    }
}

class D extends C

{
    public D(){
            System.out.println("Constructor of D Class");
    }
}
public class A extends D
{
    // instance variables - replace the example below with your own
    protected int x;
    public A(){
            System.out.println("Constructor of A Class");
    }
    public static void main(String[] args)
    {
        A obj1 = new A();
        //System.out.println(obj1.y);
    }
}


