package ClassB;

class Engine {
    public void start() {
        System.out.println("Engine started");
    }
}

class Car1 {
    private Engine engine; // Composition
    
    public Car1() {
        this.engine = new Engine();
    }
    
    public void start() {
        engine.start();
        System.out.println("Car started");
    }
}

public class Composition {
    public static void main(String[] args) {
        Car1 car = new Car1();
        car.start(); // Output: Engine started \n Car started
    }
}
