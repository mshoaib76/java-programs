package ClassB;

class Address {
    private String city;
    private String street;
    
    public Address(String city, String street) {
        this.city = city;
        this.street = street;
    }
    
    public String getCity() {
        return city;
    }
    
    public String getStreet() {
        return street;
    }
    
}

class Person {
    private String name;
    private Address address; // Aggregation
    
    public Person(String name, Address address) {
        this.name = name;
        this.address = address;
    }
    
    public String getName() {
        return name;
    }
    
    public Address getAddress() {
        return address;
    }
}

public class AggregationTest {
    public static void main(String[] args) {
        Address address = new Address("New York", "Broadway");
        Person person = new Person("John", address);
        
        // Accessing person's name and address
        System.out.println("Person's name: " + person.getName());
        System.out.println("Person's address: " + person.getAddress().getStreet() + ", " + person.getAddress().getCity());
    }
}
