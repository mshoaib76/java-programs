package ClassB;

class Animal {
    public void makeSound() {
        System.out.println("Animal makes a sound");
    }
}

class Dog extends Animal {
    public void makeSound() {
        System.out.println("Dog barks");
    }
}

class Cat extends Animal {
    public void makeSound() {
        System.out.println("Cat meows");
    }
}

public class Main {
    public static void main(String[] args) {
        Animal animal = new Dog(); // Upcasting
        Cat cat = (Cat) animal; // ClassCastException here //DownCasting
        
        cat.makeSound(); // This line won't be reached due to the exception
        
        
        
     //    if (animal instanceof Cat) {
     //       Cat cat = (Cat) animal;
     //       cat.makeSound();
     //   } else {
     //       System.out.println("Animal is not a cat");
     //   }
    }
}
