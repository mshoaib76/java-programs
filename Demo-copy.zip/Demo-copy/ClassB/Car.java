package ClassB;



public interface Car
{
    
   
    void sampleMethod();
    int a = 10;
}
