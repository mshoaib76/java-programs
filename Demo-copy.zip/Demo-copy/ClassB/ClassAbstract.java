package ClassB;


/**
 * Write a description of class ClassAbstract here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

abstract class Vehicle
{
    Vehicle(){
        System.out.println("Default Constructor");
    }
    
    public abstract void move();
    
    public void speed(){
        
        System.out.println("Vehicle Maximum Speed is 100mph");
    }
    
    
   
}
public class ClassAbstract extends Vehicle
{
    public void move(){
        
        System.out.println("Car is Moving");
    }
    
    public void sampleMethod(){
        System.out.println("Car is Moving");
    }
    
    
    public static void main(String[] args)
    {
        Vehicle s1 = new Vehicle();
        s1.move();
        
    }
}
