package ClassB;


/**
 * Write a description of class ClassInterface here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ClassInterface implements Car
{
    static int b = 10;
    public void sampleMethod(){
        System.out.println("Car is Moving");
    }
    
    public static void main(String[] args)
    {
    
        ClassInterface s1 = new ClassInterface();
        s1.sampleMethod();
        s1.a= 12;
        System.out.println(b);
    }
}
