package ClassB;


/**
 * Write a description of class ClassAbstract here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */



