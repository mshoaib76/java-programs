package ClassB;
import ClassA.*;

/**
 * Write a description of class B here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
class E{
        
    void run(){
            System.out.println("Running SuperClass");
    }

}
public class B extends E
{
    void run(){
            System.out.println("Running SubClass");
    }
    public static void main(String[] args)
    {
        E obj1 = new B();
        //System.out.println(obj1.x);
        obj1.run();
    }
}
