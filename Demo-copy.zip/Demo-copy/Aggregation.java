class Address {
    private String city;
    private String street;
    
    public Address (String city,String street)
    {
        this.city = city;
        this.street = street;
    }
}

class Person {
    private String name;
    private Address address; // Aggregation
    
    public Person(String name, Address address) {
        this.name = name;
        this.address = address;
    }
}

public class Aggregation{
    public static void main(String[] args) {
        Address address = new Address("New York", "Broadway");
        Person person = new Person("John", address);
        
    }
}
