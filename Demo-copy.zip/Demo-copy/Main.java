class Shape {
    void draw() {
        System.out.println("Drawing a shape");
    }
}

class Circle extends Shape {
    @Override
    void draw() {
        System.out.println("Drawing a circle");
    }
}

class Rectangle extends Shape {
    @Override
    void draw() {
        System.out.println("Drawing a rectangle");
    }
}

public class Main {
    static void drawShape(Shape shape) {
        shape.draw();
    }
    
    public static void main(String[] args) {
        Shape circle = new Circle(); // Upcasting
        Shape rectangle = new Rectangle(); // Upcasting
        
        drawShape(circle); // Output: Drawing a circle
        drawShape(rectangle); // Output: Drawing a rectangle
    }
}
